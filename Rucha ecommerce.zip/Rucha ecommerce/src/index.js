const express = require('express')
const path = require('path')
require('./db/mongoose.js')


const userRouter = require('./routers/user.js')
const productRouter = require('./routers/product.js')

const publicDir = path.join(__dirname, '../public')

const app = express()


app.set('view engine', 'hbs')
app.use(express.static(publicDir))


app.use(express.json())
app.use(userRouter)
app.use(productRouter)

const port = process.env.PORT || 3000


app.listen(port, () => {
    console.log('Ecommerce server started on port ' + port)
})