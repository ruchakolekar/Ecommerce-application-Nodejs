const User = require('../models/user')
const Product = require('../models/product')
const moment = require('moment')

async function createUser(req, res){
    const user = new User(req.body)

    // *Using async and await
    try {
        await user.save()

        const token = await user.generateAuthToken()

        res.status(201).send({
            user,
            token
        })
    } catch (e) {
        res.status(400).send(e)
    }
}

async function deleteUserAvatar(req, res){
     req.user.avatar = undefined
     await req.user.save()
     res.send()
}

async function viewUserAvatar(req, res){
    const user = await User.findById(req.user._id)
    try {
        if (!user || !user.avatar) {
            throw new Error()
        }

        res.set('Content-Type', 'image/png')
        res.send(user.avatar)
    } catch (e) {
        console.log(e)
        res.status(404).send()
    }
}

async function loginUser(req, res){
    try {
        const user = await User.findByCredentials(req.body.email, req.body.pass)
        const token = await user.generateAuthToken()
        res.send({
            user,
            token
        })
    } catch (e) {
        res.status(400).send()
    }
}

async function logoutUser(req, res){
    try {
        req.user.tokens = req.user.tokens.filter((token) => {
            return token.token !== req.token
        })
        await req.user.save()
        res.send()
    } catch (e) {
        res.status(500).send()
    }
}

async function logoutUserALL(req, res){
    try {
        req.user.tokens = []
        await req.user.save()
        res.send()
    } catch (e) {
        res.status(500).send()
    }
}

async function updateUser(req, res){
    const allowedUpdates = ['name', 'email', 'pass', 'age', 'contact', 'address']
    const updates = Object.keys(req.body)

    const isValidOperation = updates.every((update) => {
        return allowedUpdates.includes(update)
    })

    if (!isValidOperation) {
        return res.status(400).send({
            error: "Invalid Update Operation!"
        })
    }

    try {
        updates.forEach((update) => req.user[update] = req.body[update])

        await req.user.save()

        // ! findByIdAndUpdate can bypass middlewares
        // const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true})

        res.status(200).send(req.user)
    } catch (e) {
        if (e.name === 'CastError') {
            res.status(404).send('User not Found')
        }
        res.status(400).send(e)
    }
}

async function deleteUser(req, res){
    try {
        await req.user.remove()
        try {
            sendCancelEmail(req.user.email, req.user.name)
        } catch (e) {

        }

        res.status(200).send(req.user)
    } catch (e) {
        if (e.name === 'CastError') {
            return res.status(404).send('No such user found')
        }
        res.status(500).send(e)
    }
}

async function viewUserCart(req, res){
    //* check for price updates
    const products = req.user.cart.products
    var total = 0;
    var i;
    for (i = 0; i < products.length; i++) {
        var find = await Product.findById(products[i]._id).exec();
        total += (parseFloat(find.price) * products[i].quantity)

    }
    if (total !== req.user.cart.total) {
        req.user.cart.total = total
        await req.user.save()
    }

    res.send(req.user.cart)
}

async function viewUserOrders(req, res){
    const match = {}


    if (req.query.sortBy) {
        const parts = req.query.sortBy.split(':')

        if (parts[0] === 'amount') {
            if (parts[1] === 'desc') {
                req.user.orders = req.user.orders.sort(function (a, b) {
                    return b.amount - a.amount
                })
            } else {
                req.user.orders = req.user.orders.sort(function (a, b) {
                    return a.amount - b.amount
                })
            }
        }

    }


    if (req.query.completed) {
        match.completed = req.query.completed === 'true'
        const orders = req.user.orders.filter((order) => {
            return order.completed === match.completed
        })

        return res.send(orders)
    }

    res.send(req.user.orders)
}

async function userCartOperations(req, res){
    const matchIndex = req.user.cart.products.findIndex((product) => {
        return product._id === req.body.product_id
    })
    const product = await Product.findById(req.body.product_id).exec()

    try {
        if (req.query.product === 'add') {

            // Check Product Availability
            if (product.quantity === 0) {
                if (product.InStock !== false) {
                    product.InStock = false
                    await product.save()
                }
                return res.status(400).send('Product is out of Stock')
            }

            // Add available product to cart
            if (matchIndex === -1) {
                req.user.cart.products.push({
                    "_id": req.body.product_id,
                    "quantity": 1
                })

            } else {
                req.user.cart.products[matchIndex].quantity++

            }
            if (!parseFloat(req.user.cart.total)) {
                req.user.cart.total = product.price

            } else {
                req.user.cart.total = parseFloat(req.user.cart.total) + parseFloat(product.price)
            }

            // Remove Product quantity from stock
            product.quantity--

        } else if (req.query.product === 'remove') {

            if (matchIndex === -1) {
                return res.status(404).send()
            } else if (req.user.cart.products[matchIndex].quantity === 1) {
                req.user.cart.products.splice(matchIndex, 1)
            } else {
                req.user.cart.products[matchIndex].quantity--
            }

            if (!parseFloat(req.user.cart.total)) {
                req.user.cart.total = 0.0

            } else {
                req.user.cart.total = parseFloat(req.user.cart.total) - parseFloat(product.price)
                if (parseFloat(req.user.cart.total) < 0.01) {
                    req.user.cart.total = 0.0
                }
            }
            // Add Product quantity to stock
            if (product.InStock === false) {
                product.InStock = true
            }
            product.quantity++
        }

        await product.save()
        await req.user.save()
        res.status(200).send(req.user.cart)
    } catch (e) {

        res.status(400).send(e)
    }
}


async function placeNewOrder(req, res){
    if (req.user.cart.products !== []) {
        await req.user.orders.push({
            "products": req.user.cart.products,
            "amount": parseFloat(req.user.cart.total),
            "date": moment().format('YYYY-MM-DD') + ' ' + moment().format('h:mm A')
        })

        req.user.cart.products = []
        req.user.cart.total = 0.0
        await req.user.save()

    } else {
        return res.status(400).send({
            Error: 'No Products in Cart. Add products to cart to place order.'
        })
    }

    res.status(200).send("Your order has been placed Successfully!! Kindly note the orderID - " + req.user.orders[req.user.orders.length - 1]._id)
}

async function setOrderDelivered(req, res){
    const order = await req.user.orders.find(ord => ord._id.toString() === req.params.id)
    try {
        order.completed = true
        await req.user.save()
        res.status(200).send(order)
    } catch (e) {
        res.status(400).send(e)
    }
}

async function adminViewUsers(req, res){
    const sort = {}
    const match = {}

    if (req.query.sortBy) {
        const parts = req.query.sortBy.split(':')

        if (parts[1] === 'desc') {
            sort[parts[0]] = -1

        } else {
            sort[parts[0]] = 1
        }
    }

    if (req.query.city) {
        match['address.city'] = req.query.city
    }
    if (req.query.role) {
        match.role = req.query.role
    }
    if (req.query.age) {
        const parts = req.query.age.split(':')
        if (parts[0] === 'eq') {
            match.age = parts[1]
        } else if (parts[0] === 'gt') {
            match.age = {}
            match.age['$gt'] = parts[1]
        } else if (parts[0] === 'lt') {
            match.age = {}
            match.age['$lt'] = parts[1]
        }
    }
    if (req.query.fname) {
        match['name.firstName'] = req.query.fname
    }
    if (req.query.lname) {
        match['name.lastName'] = req.query.lname
    }
    if (req.query.email) {
        match.email = req.query.email
    }
    if (req.query.contact) {
        match.contact = req.query.contact
    }
    if (req.query.cart) {
        const parts = req.query.cart.split(':')
        if (parts[0] === 'products' & parts[1] === 'empty') {
            match['cart.products'] = []
            match['cart.total'] = 0
        } else if (parts[0] === 'products') {
            match['cart.products._id'] = parts[1]
        } else if (parts[0] === 'total') {
            const parts1 = parts[1].split('_')
            if (parts1[0] === 'eq') {
                match['cart.total'] = parts1[1]
            } else if (parts1[0] === 'gt') {
                match['cart.total'] = {
                    '$gt': parts1[1]
                }
            } else if (parts1[0] === 'lt') {
                match['cart.total'] = {
                    '$lt': parts1[1]
                }
            }
        }
    }
    if (req.query.orders) {
        const parts = req.query.orders.split(':')
        if (parts[0] === 'products') {
            match['orders.products._id'] = parts[1]
        } else if (parts[0] === 'completed') {
            match['orders.completed'] = parts[1]
        } else if (parts[0] === 'date') {
            match['orders.date'] = parts[1]
        } else if (parts[0] === 'amount') {
            const parts1 = parts[1].split('_')
            if (parts1[0] === 'eq') {
                match['orders.amount'] = parts1[1]
            } else if (parts1[0] === 'gt') {
                match['orders.amount'] = {
                    '$gt': parts1[1]
                }
            } else if (parts1[0] === 'lt') {
                match['orders.amount'] = {
                    '$lt': parts1[1]
                }
            }
        }
    }

    users = await User.find(match).sort(sort)

    try {
        res.status(200).send(users)
    } catch (e) {
        res.status(500).send(e)
    }
}

async function adminUpdateUserCart(req, res){
    const allowedUpdates = ['cart']
    const updates = Object.keys(req.body)

    const isValidOperation = updates.every((update) => {
        return allowedUpdates.includes(update)
    })

    if (!isValidOperation) {
        return res.status(400).send({
            error: "Invalid Update Operation!"
        })
    }

    const user = await User.findById(req.params.id).exec()
    try {
        updates.forEach((update) => user[update] = req.body[update])

        await user.save()

        // ! findByIdAndUpdate can bypass middlewares
        // const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true})

        res.status(200).send(user)
    } catch (e) {
        if (e.name === 'CastError') {
            res.status(404).send('User not Found')
        }
        res.status(400).send(e)
    }
}

async function adminUpdateUserOrders(req, res){
    const allowedUpdates = ['orders']
    const updates = Object.keys(req.body)

    const isValidOperation = updates.every((update) => {
        return allowedUpdates.includes(update)
    })

    if (!isValidOperation) {
        return res.status(400).send({
            error: "Invalid Update Operation!"
        })
    }

    const user = await User.findById(req.params.id).exec()
    try {
        updates.forEach((update) => user[update] = req.body[update])

        await user.save()

        // ! findByIdAndUpdate can bypass middlewares
        // const user = await User.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true})

        res.status(200).send(user)
    } catch (e) {
        console.log(e)
        if (e.name === 'CastError') {
            res.status(404).send('User not Found')
        }
        res.status(400).send(e)
    }
}

module.exports = {
    createUser,
    deleteUserAvatar,
    viewUserAvatar,
    loginUser,
    logoutUser,
    logoutUserALL,
    updateUser,
    deleteUser,
    viewUserCart,
    viewUserOrders,
    userCartOperations,
    placeNewOrder,
    setOrderDelivered,
    adminViewUsers,
    adminUpdateUserCart,
    adminUpdateUserOrders
}