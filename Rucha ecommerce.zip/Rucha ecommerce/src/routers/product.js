const express = require('express')
const {auth, authAdmin}  = require('../middleware/auth.js')
const router = new express.Router()
const { 
    addNewProduct,
    readProducts,
    readProductById,
    updateProduct,
    deleteProductById
} = require('../controllers/productController.js')


// *Add Product
router.post('/products/add', authAdmin, addNewProduct)


// * Read Products
router.get('/products', auth, readProducts)


// *Read Product by ID
router.get('/products/:id', auth, readProductById)


// *Update Product by ID
router.patch('/products/:id', authAdmin, updateProduct)


// *Delete Product by ID
router.delete('/products/:id', authAdmin, deleteProductById)

module.exports = router